from os import path
from tkinter import *

import pandas as pd
import csv
import tkinter as t
from tkinter.constants import END
from tkinter.filedialog import askopenfile

root = t.TK()
root.title("Population Generator - Search by state and year")
root.geometry('1000x500')

canvas = t.Canvas(root, width=250, height=150)
canvas.grid()

states = []
years = []

with open("input.csv") as csv_file:
    reader = csv.reader(csv_file)
    next(reader)
    for categories in reader:
        selection_list = categories[8].split('>')
        selection_list2 = years[8].split('>')

        if selection_list[0] not in states or years:
            states.append(selection_list[0])
            years.append(selection_list2[0])
        states.sort()
        years.sort()

category_menu = t.StringVar(root)
category_menu.set("select by Year and State")

o = t.OptionMenu(root, category_menu)
o.place(x=400, y=50)

entry= t.Entry(root, width=10, justify='center')

canvas.create_window(150,100,window= entry)
entry.place(x=440, y=120)

text_box = t.Text(root, width=200, height = 30)
text_box.grid(row=4, column= 0, columnspan= 2)

def show_population():
    text_box.delete('1.0', END)
    user_input = int(entry.get())

    data = pd.read_csv("output.csv")
            
    


