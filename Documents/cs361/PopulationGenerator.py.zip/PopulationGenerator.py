from os import path
from tkinter import *

import pandas as pd
import csv
import tkinter as t
from tkinter.constants import END
from tkinter.filedialog import askopenfile



root = t.TK()
root.title("Population Generator - Search by state and year")
root.geometry('1000x500')

canvas = t.Canvas(root, width=250, height=150)
canvas.grid()

states = []
years = []

with open("input.csv") as csv_file:
    reader = csv.reader(csv_file)
    next(reader)
    for categories in reader:
        selection_list = categories[8].split('>')
        selection_list2 = years[8].split('>')

        if selection_list[0] not in states or years:
            states.append(selection_list[0])
            years.append(selection_list2[0])
        states.sort()
        years.sort()

category_menu = t.StringVar(root)
category_menu.set("select by Year and State")

o = t.OptionMenu(root, category_menu)
o.place(x=400, y=50)

entry= t.Entry(root, width=10, justify='center')

canvas.create_window(150,100,window= entry)
entry.place(x=440, y=120)

text_box = t.Text(root, width=200, height = 30)
text_box.grid(row=4, column= 0, columnspan= 2)

def show_population():
    text_box.delete('1.0', END)
    user_input = int(entry.get())

    data = pd.read_csv("output.csv")
    pd.set_option('display.max_colums', None)
    pd.set_option('display.max_rows',None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('colheader_justify','left')
    data.head()

    selection_list.reset_index(drop=True, inplace=True)

    text_box.insert("end", selection_list[["year","state","population"]].head(user_input))

button1 = t.Button(root, text='display population', command=show_population, bg='grey',fg='white').grid(row=3)
canvas.create_window(150,140,window=button1)

if path.exists('input.csv'):

    with open('input.csv', 'r',) as file:
        reader= csv.reader(file, delimiter=',')
        next(file)
        for row in reader:
            category_chosen =row[1]
            number_gen = row[2]
        if not category_chosen:
            category_chosen= None
        if not number_gen:
            number_gen = 0
    output = pd.read_csv("output.csv")

    to_excel = {'input_item_type': 'states', 'input_item_category': category_chosen, 'input_number_to_generate': number_gen, 'output_item_name': ["state_name"]}

    df= pd.DataFrame(to_excel)

    df.to_csv('output.csv', index=False)



            
    


